# Minor-2 > 2025-07-05 8:56pm
https://universe.roboflow.com/smart-workspace-mn3lx/minor-2

Provided by a Roboflow user
License: Public Domain

